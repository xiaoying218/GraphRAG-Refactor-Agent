"""Lightweight evaluation utilities for the demo.

This package is intentionally dependency-light so you can ship a reproducible
benchmark/evaluation story alongside the refactoring demo.
"""
