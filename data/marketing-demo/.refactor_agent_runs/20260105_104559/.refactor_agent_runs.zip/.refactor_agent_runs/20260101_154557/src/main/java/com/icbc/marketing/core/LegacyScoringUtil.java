package com.icbc.marketing.core;

import java.util.Map;

/**
 * [Legacy Component]
 * A static utility class used across the system for basic scoring.
 * Refactoring Target: High coupling. If this changes, everything breaks.
 */
public class LegacyScoringUtil {

    // Magic number alert: 0.618
    private static final double GOLDEN_RATIO = 0.618;

    /**
     * Calculates a base user score.
     * @deprecated Use {@link #calculateBaseScore(Map, String)} with explicit region.
     */
    @Deprecated(since = "1.1", forRemoval = false)
    public static double calculateBaseScore(Map<String, Object> flinkFeatures) {
        return calculateBaseScore(flinkFeatures, "DEFAULT");
    }

    /**
     * Calculates a base user score with region context.
     * @param flinkFeatures feature map
     * @param region geographic region (e.g., "CN", "US", "EU"); default region "DEFAULT" preserves legacy behavior
     * @return base score
     */
    public static double calculateBaseScore(Map<String, Object> flinkFeatures, String region) {
        double txnVolume = (double) flinkFeatures.getOrDefault("last_1h_txn_amt", 0.0);
        int loginCount = (int) flinkFeatures.getOrDefault("login_count_7d", 0);

        // Simple linear hard-coded logic (region‑aware extension point)
        // TODO: incorporate region‑specific coefficients or rules
        return (txnVolume * 0.001) + (loginCount * 10) * GOLDEN_RATIO;
    }

    public static boolean isBlacklisted(String userId) {
        // Mock DB call
        return userId.startsWith("B_");
    }
}
