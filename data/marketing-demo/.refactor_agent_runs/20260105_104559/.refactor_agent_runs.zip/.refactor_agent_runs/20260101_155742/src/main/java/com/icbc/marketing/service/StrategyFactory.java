package com.icbc.marketing.service;

import com.icbc.marketing.strategy.IPromotionStrategy;
import com.icbc.marketing.strategy.impl.HighValueStrategy;
import com.icbc.marketing.strategy.impl.FrequentUserStrategy;
import com.icbc.marketing.strategy.impl.NewUserStrategy;

import java.util.List;
import java.util.ArrayList;

/**
 * Factory for creating and managing promotion strategies.
 * Supports dependency injection and strategy assembly.
 */
public interface StrategyFactory {
    /**
     * Get all strategies in order of priority.
     * @return list of IPromotionStrategy instances
     */
    List<IPromotionStrategy> getStrategies();
}

/**
 * Default implementation that assembles strategies as per original engine.
 */
class DefaultStrategyFactory implements StrategyFactory {
    @Override
    public List<IPromotionStrategy> getStrategies() {
        List<IPromotionStrategy> strategies = new ArrayList<>();
        strategies.add(new HighValueStrategy());
        strategies.add(new FrequentUserStrategy());
        strategies.add(new NewUserStrategy());
        return strategies;
    }
}
