package com.icbc.marketing.service;

import com.icbc.marketing.core.LegacyScoringUtil;
import com.icbc.marketing.strategy.IPromotionStrategy;
import com.icbc.marketing.strategy.impl.HighNetWorthStrategy;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * [The Core System]
 * Real-time Decision Engine.
 * Responsibilities:
 * 1. Metric Analysis (Consume Flink data)
 * 2. Risk Pre-screening (Safety Guardrails) - 【风控在这里！】
 * 3. Marketing Strategy Execution (Recommendation) - 【推荐在这里！】
 */
public class CampaignDecisionEngine {

    private final RiskControlService riskControlService;
    private final StrategyExecutor strategyExecutor;
    private final StrategyFactory strategyFactory;

    public CampaignDecisionEngine() {
        this.riskControlService = new DefaultRiskControlService();
        this.strategyFactory = new DefaultStrategyFactory();
        this.strategyExecutor = new DefaultStrategyExecutor(strategyFactory.createStrategies());
    }

    public CampaignDecisionEngine(RiskControlService riskControlService,
                                  StrategyExecutor strategyExecutor,
                                  StrategyFactory strategyFactory) {
        this.riskControlService = riskControlService;
        this.strategyExecutor = strategyExecutor;
        this.strategyFactory = strategyFactory;
    }

    public String decideOffer(String userId, Map<String, Object> realTimeFeatures) {
        System.out.println("Processing decision for user: " + userId);

        // =========================================================
        // Step 1: Risk Control Layer (Pre-computation) 【风控层】
        // =========================================================
        String riskResult = riskControlService.performRiskChecks(userId, realTimeFeatures);
        if (riskResult != null) {
            return riskResult;
        }

        // =========================================================
        // Step 2: Marketing Strategy Layer (Recommendation) 【推荐层】
        // =========================================================
        return strategyExecutor.executeStrategy(userId, realTimeFeatures);
    }

    // Inner interfaces and default implementations for dependency injection
    public interface RiskControlService {
        String performRiskChecks(String userId, Map<String, Object> realTimeFeatures);
    }

    public interface StrategyExecutor {
        String executeStrategy(String userId, Map<String, Object> realTimeFeatures);
    }

    public interface StrategyFactory {
        List<IPromotionStrategy> createStrategies();
    }

    private static class DefaultRiskControlService implements RiskControlService {
        @Override
        public String performRiskChecks(String userId, Map<String, Object> realTimeFeatures) {
            if (LegacyScoringUtil.isBlacklisted(userId)) {
                return "BLOCK: User is Blacklisted (Risk Control)";
            }

            double baseScore = LegacyScoringUtil.calculateBaseScore(realTimeFeatures);
            if (baseScore < 0) {
                return "BLOCK: Activity Score too low (Metric Filter)";
            }

            return null; // No risk block
        }
    }

    private static class DefaultStrategyExecutor implements StrategyExecutor {
        private final List<IPromotionStrategy> strategies;

        DefaultStrategyExecutor(List<IPromotionStrategy> strategies) {
            this.strategies = strategies;
        }

        @Override
        public String executeStrategy(String userId, Map<String, Object> realTimeFeatures) {
            for (IPromotionStrategy strategy : strategies) {
                if (strategy.isApplicable(realTimeFeatures)) {
                    return strategy.execute(userId, realTimeFeatures);
                }
            }
            return "DEFAULT: General Savings Promo";
        }
    }

    private static class DefaultStrategyFactory implements StrategyFactory {
        @Override
        public List<IPromotionStrategy> createStrategies() {
            List<IPromotionStrategy> strategies = new ArrayList<>();
            strategies.add(new HighNetWorthStrategy());
            return strategies;
        }
    }
}
