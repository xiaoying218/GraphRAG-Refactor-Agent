package com.icbc.marketing.service;

import com.icbc.marketing.strategy.IPromotionStrategy;
import java.util.List;
import java.util.Map;

/**
 * Executes marketing strategies to determine the best offer for a user.
 * This component encapsulates the strategy selection and execution logic,
 * separating it from risk control and strategy assembly.
 */
public interface StrategyExecutor {

    /**
     * Executes the appropriate strategy based on real-time features.
     *
     * @param userId the user identifier
     * @param realTimeFeatures real-time user features
     * @param strategies list of available promotion strategies
     * @return the offer decision string
     */
    String execute(String userId, Map<String, Object> realTimeFeatures, List<IPromotionStrategy> strategies);
}
