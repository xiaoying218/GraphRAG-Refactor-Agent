package com.icbc.marketing.service;

import java.util.Map;

/**
 * Service responsible for performing risk control checks.
 * Encapsulates risk logic previously inside CampaignDecisionEngine.
 */
public interface RiskControlService {

    /**
     * Perform risk checks for a given user and features.
     *
     * @param userId the user identifier
     * @param realTimeFeatures real‑time feature map
     * @return a risk result; if the user passes, returns {@code null} or an empty string,
     *         otherwise returns a block reason (non‑null).
     */
    String performRiskChecks(String userId, Map<String, Object> realTimeFeatures);
}
