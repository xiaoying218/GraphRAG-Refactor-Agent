package com.icbc.marketing.service;

import com.icbc.marketing.core.LegacyScoringUtil;
import com.icbc.marketing.strategy.IPromotionStrategy;
import com.icbc.marketing.strategy.impl.HighNetWorthStrategy;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * [The Core System]
 * Real-time Decision Engine.
 * Responsibilities:
 * 1. Metric Analysis (Consume Flink data)
 * 2. Risk Pre-screening (Safety Guardrails) - 【风控在这里！】
 * 3. Marketing Strategy Execution (Recommendation) - 【推荐在这里！】
 */
public class CampaignDecisionEngine {

    private final RiskControlService riskControlService;
    private final StrategyFactory strategyFactory;

    /**
     * Default constructor for backward compatibility.
     * Uses default implementations of RiskControlService and StrategyFactory.
     */
    public CampaignDecisionEngine() {
        this(new DefaultRiskControlService(), new DefaultStrategyFactory());
    }

    /**
     * Constructor for dependency injection.
     * @param riskControlService the risk control service
     * @param strategyFactory the strategy factory
     */
    public CampaignDecisionEngine(RiskControlService riskControlService, StrategyFactory strategyFactory) {
        this.riskControlService = riskControlService;
        this.strategyFactory = strategyFactory;
    }

    public String decideOffer(String userId, Map<String, Object> realTimeFeatures) {
        System.out.println("Processing decision for user: " + userId);

        // =========================================================
        // Step 1: Risk Control Layer (Pre-computation) 【风控层】
        // =========================================================
        String riskResult = riskControlService.performRiskControl(userId, realTimeFeatures);
        if (riskResult != null) {
            return riskResult;
        }

        // =========================================================
        // Step 2: Marketing Strategy Layer (Recommendation) 【推荐层】
        // =========================================================
        List<IPromotionStrategy> strategies = strategyFactory.getStrategies();
        for (IPromotionStrategy strategy : strategies) {
            // Strategies ALSO depend on the metrics calculated above
            if (strategy.isApplicable(realTimeFeatures)) {
                return strategy.execute(userId, realTimeFeatures);
            }
        }

        return "DEFAULT: General Savings Promo";
    }

    // =========================================================
    // Inner interfaces and default implementations
    // =========================================================

    /**
     * Service for risk control logic.
     */
    public interface RiskControlService {
        /**
         * Perform risk control checks.
         * @param userId the user ID
         * @param realTimeFeatures real-time features
         * @return a block message if risk is detected, null otherwise
         */
        String performRiskControl(String userId, Map<String, Object> realTimeFeatures);
    }

    /**
     * Default implementation of RiskControlService that encapsulates LegacyScoringUtil.
     */
    public static class DefaultRiskControlService implements RiskControlService {
        @Override
        public String performRiskControl(String userId, Map<String, Object> realTimeFeatures) {
            // 检查 1: 黑名单风控
            if (LegacyScoringUtil.isBlacklisted(userId)) {
                return "BLOCK: User is Blacklisted (Risk Control)";
            }

            // 检查 2: 基础指标门槛风控
            double baseScore = LegacyScoringUtil.calculateBaseScore(realTimeFeatures);
            if (baseScore < 0) {
                return "BLOCK: Activity Score too low (Metric Filter)";
            }

            return null;
        }
    }

    /**
     * Factory for creating strategy instances.
     */
    public interface StrategyFactory {
        /**
         * Get the list of promotion strategies.
         * @return list of strategies
         */
        List<IPromotionStrategy> getStrategies();
    }

    /**
     * Default implementation of StrategyFactory that provides the default strategies.
     */
    public static class DefaultStrategyFactory implements StrategyFactory {
        @Override
        public List<IPromotionStrategy> getStrategies() {
            List<IPromotionStrategy> strategies = new ArrayList<>();
            strategies.add(new HighNetWorthStrategy());
            return strategies;
        }
    }
}
