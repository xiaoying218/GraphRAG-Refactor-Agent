package com.icbc.marketing.core;

import java.util.Map;

/**
 * [Legacy Component]
 * A static utility class used across the system for basic scoring.
 * Refactoring Target: High coupling. If this changes, everything breaks.
 */
public class LegacyScoringUtil {

    // Magic number alert: 0.618
    private static final double GOLDEN_RATIO = 0.618;

    /**
     * Region enum representing different regions with their specific coefficients.
     */
    public enum Region {
        DEFAULT(1.0, 1.0),
        NORTH_AMERICA(1.2, 0.9),
        EUROPE(1.1, 1.05),
        ASIA_PACIFIC(0.95, 1.15);

        private final double txnCoefficient;
        private final double loginCoefficient;

        Region(double txnCoefficient, double loginCoefficient) {
            this.txnCoefficient = txnCoefficient;
            this.loginCoefficient = loginCoefficient;
        }

        public double getTxnCoefficient() {
            return txnCoefficient;
        }

        public double getLoginCoefficient() {
            return loginCoefficient;
        }
    }

    /**
     * Calculates a base user score.
     * @deprecated Logic is outdated, should be refactored to handle "Region" context.
     * Use {@link #calculateBaseScore(Map, Region)} instead.
     */
    @Deprecated
    public static double calculateBaseScore(Map<String, Object> flinkFeatures) {
        return calculateBaseScore(flinkFeatures, Region.DEFAULT);
    }

    /**
     * Calculates a base user score with explicit region context.
     * @param flinkFeatures map of features
     * @param region region to apply region-specific coefficients
     * @return base score
     */
    public static double calculateBaseScore(Map<String, Object> flinkFeatures, Region region) {
        double txnVolume = (double) flinkFeatures.getOrDefault("last_1h_txn_amt", 0.0);
        int loginCount = (int) flinkFeatures.getOrDefault("login_count_7d", 0);

        // Apply region-specific coefficients
        double txnComponent = txnVolume * 0.001 * region.getTxnCoefficient();
        double loginComponent = (loginCount * 10) * GOLDEN_RATIO * region.getLoginCoefficient();

        return txnComponent + loginComponent;
    }

    public static boolean isBlacklisted(String userId) {
        // Mock DB call
        return userId.startsWith("B_");
    }
}
