package com.icbc.marketing.core;

import java.util.Map;

/**
 * 决策上下文，用于在一次决策过程中共享计算中间结果（如 baseScore），
 * 避免重复计算，同时为未来扩展（如 Region 上下文）提供统一容器。
 */
public class DecisionContext {
    private final String userId;
    private final Map<String, Object> realTimeFeatures;
    private Double cachedBaseScore = null;

    public DecisionContext(String userId, Map<String, Object> realTimeFeatures) {
        this.userId = userId;
        this.realTimeFeatures = realTimeFeatures;
    }

    public String getUserId() {
        return userId;
    }

    public Map<String, Object> getRealTimeFeatures() {
        return realTimeFeatures;
    }

    /**
     * 获取基础分数，如果尚未计算则惰性计算并缓存。
     * 计算逻辑委托给 LegacyScoringUtil.calculateBaseScore。
     */
    public double getBaseScore() {
        if (cachedBaseScore == null) {
            cachedBaseScore = LegacyScoringUtil.calculateBaseScore(realTimeFeatures);
        }
        return cachedBaseScore;
    }

    /**
     * 检查用户是否在黑名单中。
     */
    public boolean isBlacklisted() {
        return LegacyScoringUtil.isBlacklisted(userId);
    }
}
