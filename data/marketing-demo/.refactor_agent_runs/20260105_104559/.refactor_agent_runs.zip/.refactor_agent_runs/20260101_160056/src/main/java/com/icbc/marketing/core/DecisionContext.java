package com.icbc.marketing.core;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 决策上下文，用于在决策链路中共享数据和缓存计算结果。
 * 支持扩展，未来可添加 Region 上下文等。
 */
public class DecisionContext {
    private final Map<String, Object> flinkFeatures;
    private final Map<String, Object> cache = new ConcurrentHashMap<>();

    // 缓存键常量
    private static final String CACHE_KEY_BASE_SCORE = "baseScore";

    public DecisionContext(Map<String, Object> flinkFeatures) {
        this.flinkFeatures = flinkFeatures;
    }

    public Map<String, Object> getFlinkFeatures() {
        return flinkFeatures;
    }

    /**
     * 获取基础分数，确保一次决策只计算一次。
     * 线程安全，懒加载。
     *
     * @return 基础分数
     */
    public double getBaseScore() {
        return (double) cache.computeIfAbsent(CACHE_KEY_BASE_SCORE, key -> {
            // 委托给 LegacyScoringUtil 计算
            return LegacyScoringUtil.calculateBaseScore(flinkFeatures);
        });
    }

    /**
     * 显式设置基础分数（主要用于测试或特殊场景）。
     *
     * @param score 基础分数
     */
    public void setBaseScore(double score) {
        cache.put(CACHE_KEY_BASE_SCORE, score);
    }

    /**
     * 获取缓存的值，泛型方法便于扩展。
     *
     * @param key 缓存键
     * @param type 期望的类型
     * @param <T> 类型参数
     * @return 缓存的值，若不存在则返回 null
     */
    @SuppressWarnings("unchecked")
    public <T> T getCached(String key, Class<T> type) {
        Object value = cache.get(key);
        return type.isInstance(value) ? (T) value : null;
    }

    /**
     * 放入缓存值，用于未来扩展（如 Region 上下文）。
     *
     * @param key 缓存键
     * @param value 缓存值
     */
    public void putCached(String key, Object value) {
        cache.put(key, value);
    }

    /**
     * 清除所有缓存（主要用于测试）。
     */
    public void clearCache() {
        cache.clear();
    }
}
