package com.icbc.marketing.core;

import java.util.Map;

public interface ScoringService {
    double calculateBaseScore(Map<String, Object> flinkFeatures);
    boolean isBlacklisted(String userId);
}
