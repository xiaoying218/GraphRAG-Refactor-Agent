package com.icbc.marketing.strategy;

import com.icbc.marketing.core.LegacyScoringUtil;
import com.icbc.marketing.core.ScoringService;
import java.util.Map;

public abstract class AbstractBaseStrategy implements IPromotionStrategy {

    protected double minScoreThreshold;
    protected ScoringService scoringService;

    public AbstractBaseStrategy(double minScoreThreshold) {
        this.minScoreThreshold = minScoreThreshold;
        // Default to legacy adapter for backward compatibility
        this.scoringService = new com.icbc.marketing.core.LegacyScoringAdapter();
    }

    public AbstractBaseStrategy(double minScoreThreshold, ScoringService scoringService) {
        this.minScoreThreshold = minScoreThreshold;
        this.scoringService = scoringService;
    }

    // Common logic shared by all subclasses
    protected boolean passBasicRiskCheck(Map<String, Object> features) {
        // DEPENDENCY ALERT: Calls the legacy static utility via adapter
        double currentScore = scoringService.calculateBaseScore(features);
        return currentScore > minScoreThreshold;
    }

    @Override
    public abstract String execute(String userId, Map<String, Object> context);
}
