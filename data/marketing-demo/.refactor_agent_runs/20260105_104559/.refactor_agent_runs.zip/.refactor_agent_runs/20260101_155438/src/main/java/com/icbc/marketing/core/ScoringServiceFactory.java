package com.icbc.marketing.core;

/**
 * Factory for obtaining scoring service instances.
 * Provides a default implementation that adapts the legacy static methods.
 */
public class ScoringServiceFactory {

    private static final ScoringService DEFAULT_INSTANCE = new LegacyScoringAdapter();

    /**
     * Returns the default scoring service instance.
     * @return a ScoringService implementation
     */
    public static ScoringService getDefaultScoringService() {
        return DEFAULT_INSTANCE;
    }

    /**
     * Creates a new scoring service instance (for future extensibility).
     * Currently returns the same default adapter.
     * @return a ScoringService implementation
     */
    public static ScoringService createScoringService() {
        return new LegacyScoringAdapter();
    }
}
