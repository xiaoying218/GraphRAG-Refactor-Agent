package com.icbc.marketing.engine;

import com.icbc.marketing.core.LegacyScoringUtil;
import java.util.HashMap;
import java.util.Map;

public class DemoRunner {
    public static void main(String[] args) {
        // 1. 准备测试数据
        Map<String, Object> flinkFeatures = new HashMap<>();
        flinkFeatures.put("last_1h_txn_amt", 5000.0);
        flinkFeatures.put("login_count_7d", 3);
        flinkFeatures.put("user_id", "U123456");

        // 2. 计算基础分（直接调用LegacyScoringUtil静态方法）
        double baseScore = LegacyScoringUtil.calculateBaseScore(flinkFeatures);
        System.out.println("Base score: " + baseScore);

        // 3. 黑名单检查（直接调用LegacyScoringUtil静态方法）
        boolean isBlacklisted = LegacyScoringUtil.isBlacklisted((String) flinkFeatures.get("user_id"));
        System.out.println("Is blacklisted: " + isBlacklisted);

        // 4. 综合评分（示例）
        double finalScore = baseScore * (isBlacklisted ? 0.0 : 1.0);
        System.out.println("Final score: " + finalScore);
    }
}
