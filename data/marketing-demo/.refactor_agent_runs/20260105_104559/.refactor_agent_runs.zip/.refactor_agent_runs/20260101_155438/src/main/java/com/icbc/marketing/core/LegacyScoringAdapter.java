package com.icbc.marketing.core;

import java.util.Map;

/**
 * Adapter that implements ScoringService by delegating to the static methods of LegacyScoringUtil.
 * This allows the engine/strategy layer to depend on an interface rather than static utility.
 */
public class LegacyScoringAdapter implements ScoringService {

    @Override
    public double calculateBaseScore(Map<String, Object> flinkFeatures) {
        return LegacyScoringUtil.calculateBaseScore(flinkFeatures);
    }

    @Override
    public boolean isBlacklisted(String userId) {
        return LegacyScoringUtil.isBlacklisted(userId);
    }
}
