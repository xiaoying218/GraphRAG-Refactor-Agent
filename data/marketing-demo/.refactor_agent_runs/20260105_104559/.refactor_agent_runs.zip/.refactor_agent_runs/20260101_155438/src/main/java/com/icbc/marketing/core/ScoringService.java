package com.icbc.marketing.core;

import java.util.Map;

/**
 * 评分服务接口，用于解耦LegacyScoringUtil的静态方法。
 * 提供基础评分和黑名单判断能力。
 */
public interface ScoringService {

    /**
     * 计算基础评分
     * @param flinkFeatures Flink特征数据
     * @return 基础评分
     */
    double calculateBaseScore(Map<String, Object> flinkFeatures);

    /**
     * 判断用户是否在黑名单中
     * @param userId 用户ID
     * @return 是否在黑名单中
     */
    boolean isBlacklisted(String userId);
}
