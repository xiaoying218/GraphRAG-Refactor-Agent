package com.icbc.marketing.core;

import java.util.Map;

/**
 * Service interface for scoring and blacklist checking.
 * Decouples the engine/strategy layer from static utility methods.
 */
public interface ScoringService {

    /**
     * Calculates a base user score.
     * @param flinkFeatures real-time features map
     * @return base score
     */
    double calculateBaseScore(Map<String, Object> flinkFeatures);

    /**
     * Checks if a user is blacklisted.
     * @param userId user identifier
     * @return true if blacklisted
     */
    boolean isBlacklisted(String userId);
}
