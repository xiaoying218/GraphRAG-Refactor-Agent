package com.icbc.marketing.core;

import java.util.Map;

/**
 * Adapter that implements ScoringService by delegating to LegacyScoringUtil static methods.
 * Preserves existing behavior for backward compatibility.
 */
public class LegacyScoringAdapter implements ScoringService {

    @Override
    public double calculateBaseScore(Map<String, Object> flinkFeatures) {
        return LegacyScoringUtil.calculateBaseScore(flinkFeatures);
    }

    @Override
    public boolean isBlacklisted(String userId) {
        return LegacyScoringUtil.isBlacklisted(userId);
    }
}
