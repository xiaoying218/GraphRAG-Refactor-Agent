package com.icbc.marketing.core;

import java.util.Map;

public class LegacyScoringAdapter implements ScoringService {
    @Override
    public double calculateBaseScore(Map<String, Object> flinkFeatures) {
        return LegacyScoringUtil.calculateBaseScore(flinkFeatures);
    }

    @Override
    public boolean isBlacklisted(String userId) {
        return LegacyScoringUtil.isBlacklisted(userId);
    }
}
